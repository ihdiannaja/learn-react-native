export const DATA = [
    {
        id : '1',
        productName : 'mouse'
    },
    {
        id : '2',
        productName : 'keyboard'
    },
    {
        id : '3',
        productName : 'monitor'
    },
    {
        id : '4',
        productName : 'deskmat'
    },
    {
        id : '5',
        productName : 'mic'
    },
    {
        id : '6',
        productName : 'speaker'
    },
    {
        id : '7',
        productName : 'webcam'
    },
    {
        id : '8',
        productName : 'gamepad'
    },
    {
        id : '9',
        productName : 'monitor lamp'
    },
    {
        id : '10',
        productName : 'headphone'
    },
    {
        id : '11',
        productName : 'usb dock'
    },
    {
        id : '12',
        productName : 'mic stand'
    },
    {
        id : '13',
        productName : 'chair'
    },
    {
        id : '14',
        productName : 'laptop stand'
    },
    {
        id : '15',
        productName : 'game console'
    },
    {
        id : '16',
        productName : 'portable monitor'
    },
    {
        id : '17',
        productName : 'wrist rest'
    },
    {
        id : '18',
        productName : 'phone holder'
    },
    {
        id : '19',
        productName : 'mechanical keyboard'
    },
    {
        id : '20',
        productName : 'pegboard'
    },
    {
        id : '21',
        productName : 'switch'
    },
    {
        id : '22',
        productName : 'monitor riser'
    },
    {
        id : '23',
        productName : 'audio interface'
    },
    {
        id : '24',
        productName : 'clock'
    },
]