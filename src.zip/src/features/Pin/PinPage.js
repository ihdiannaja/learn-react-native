import { useNavigation, useRoute } from '@react-navigation/native'
import React, { useEffect, useState } from 'react'
import { Button, FlatList, Keyboard, StyleSheet, Text, TextInput, View } from 'react-native'
import { TouchableWithoutFeedback } from 'react-native-gesture-handler'
import AppButton from '../../shared/components/AppButton'
import AppTitleLabel from '../../shared/components/AppTitleLabel'
import FormInput from '../../shared/components/FormInput'
import FormPassword from '../../shared/components/FormPassword'
import { MainContainer } from '../../shared/components/MainContainer'
// import { ROUTE } from '../../shared/Constants'
import { useTheme } from '../../shared/context/ThemeContext'
import { theme } from '../../shared/Theme'
import { NumberItem } from './components/NumberItem'

export const PinPage = () => {
    const theme = useTheme()
    const styles = styling(theme)
    const navigation = useNavigation()
    const [pin, setPin] = useState('0')
    const route = useRoute()
    const [pinParam, setPinParam] = useState({})

    useEffect(() => {
        if (route.params?.prevPage) {
            setPinParam({
                prevPage: route.params.prevPage
            })
        }
    }, [route.params])
    
    const renderItem = ({item}) => {
        return <NumberItem label={item}/>
    }

    const renderNumberViews = () => {
        let numArray = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        numArray = numArray.sort(() => Math.random() - 0.5)
        const renderArray = [] 
        for(let i=0 ; i < numArray.length/3; i++){
            const startIndex = (i * 3);
            const endIndex = (i * 3) + 3;
            const dataMenu = numArray.slice(startIndex, endIndex);
            let contentStyle = {flex: 1, justifyContent: 'space-around'}
            const m = (<FlatList
                key={i}
                horizontal
                data={dataMenu}
                renderItem={renderItem}
                keyExtractor={item=>item}
                contentContainerStyle={contentStyle}
                // onPress={() => setPin(prevState => prevState.concat(`${numArray[i]}`))}
                />
            )
            renderArray.push(m)
        }
        console.log(pin);
        return renderArray
    }

    return (
        <MainContainer>
            <View style={styles.pinContainer}>
                <View style={styles.pinView}>
                    <Text style={[theme.text.subtitle, styles.pinLabel]}>
                        Please Input PIN
                    </Text>
                    <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
                        <TextInput secureTextEntry maxLength={6} style={styles.pinInput} value={pin}/>
                    </TouchableWithoutFeedback>
                </View>
            </View>
            <AppButton label={'Submit'} 
                // onClick={() => {
                // navigation.navigate(pinParam.prevPage, {
                //     message: 'OK',
                // })
                onClick={() => {
                    navigation.reset({
                        index: 0,
                        routes: [{
                            name: pinParam.prevPage,
                            params: {message: 'OK'}
                        }]
                    })
            }}/>

            {renderNumberViews()}

        </MainContainer>
    )
}

const styling = (theme) => StyleSheet.create({
    pinInput:{
        borderBottomColor: theme.color.foreground,
        borderBottomWidth: 1,
        marginVertical: theme.spacing.l,
        fontSize: 32,
        textAlign: 'center'
    },
    pinLabel:{
        textAlign: 'center'
    },
    pinView:{
        width: '50%'
    },
    pinContainer:{
        alignItems: 'center'
    }
})