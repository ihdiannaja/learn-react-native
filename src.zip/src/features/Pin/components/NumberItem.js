import React from 'react'
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import { useTheme } from '../../../shared/context/ThemeContext'

export const NumberItem = ({label}) => {
    const theme = useTheme()
    const styles = styling(theme)
    
    return (
        <TouchableOpacity>
            <View style={styles.container}>
                <Text style={styles.textMenu}>{label}</Text>
            </View>
        </TouchableOpacity>
    )
}

const styling = (theme) => StyleSheet.create({
    container : {
        borderWidth : 1,
        borderColor : theme.color.secondary,
        borderRadius : 24,
        width : 80,
        height : 80,
        alignItems : 'center',
        justifyContent : 'center',
        backgroundColor : theme.color.light,
        margin : theme.spacing.m,
        padding : theme.spacing.s
    },
    textMenu : {
        color : theme.color.primary,
        fontFamily : 'Poppins-Medium',
        marginTop : 3
    }
})