import HomeRouter from "../../navigation/HomeRouter"

const HomePage = () => {
    return <HomeRouter />
}

export default HomePage;